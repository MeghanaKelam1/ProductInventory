package com.app.product_service.controller;

import com.app.product_service.model.DeliveryInfo;
import com.app.product_service.model.Product;
import com.app.product_service.model.ProductResponse;
import com.app.product_service.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductController {

    @Autowired
    ProductService productService;

    @GetMapping("products")
    public ResponseEntity<List<Product>> getAllProducts(){
        List<Product> productList = productService.getAllProducts();
        return ResponseEntity.ok(productList);
    }

    @GetMapping("products/{id}")
    public ResponseEntity<ProductResponse> getProductById(@PathVariable Long id){
       ProductResponse response =  productService.getProductById(id);
       return ResponseEntity.ok(response);
    }

    @PostMapping("products")
    public ResponseEntity<String> addProduct( @Valid  @RequestBody Product product ){
      productService.addProduct(product);
      return ResponseEntity.status(HttpStatus.CREATED).body("Stock added succesfully");
    }

    @GetMapping("products/delivery/{name}/{quantity}")
    public ResponseEntity<DeliveryInfo> getDeliveryDetails(@PathVariable String name,@PathVariable Integer quantity){
        DeliveryInfo info = productService.getDeliveryDetails(name,quantity);
        return ResponseEntity.ok(info);
    }


}
