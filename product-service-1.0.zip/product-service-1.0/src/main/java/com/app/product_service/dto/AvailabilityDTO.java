package com.app.product_service.dto;

public class AvailabilityDTO {
    private Long availabilityId;
    private Integer deliveryTime;
    private String store;

    public AvailabilityDTO() {}

    public AvailabilityDTO(Long availabilityId, Integer deliveryTime, String store) {
        this.availabilityId = availabilityId;
        this.deliveryTime = deliveryTime;
        this.store = store;
    }

    public Long getAvailabilityId() {
        return availabilityId;
    }

    public void setAvailabilityId(Long availabilityId) {
        this.availabilityId = availabilityId;
    }

    public Integer getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(Integer deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public String getStore() {
        return store;
    }

    public void setStore(String store) {
        this.store = store;
    }
}