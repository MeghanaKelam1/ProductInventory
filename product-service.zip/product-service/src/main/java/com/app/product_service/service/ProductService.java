package com.app.product_service.service;

import com.app.product_service.Feign.ProductInterface;
import com.app.product_service.dao.ProductRepo;
import com.app.product_service.exception.InvalidProductException;
import com.app.product_service.exception.ProductNotFoundException;
import com.app.product_service.model.Product;
import com.app.product_service.model.ProductResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    ProductRepo productRepo;

    @Autowired
    ProductInterface productInterface;

    //to get all the products
    public List<Product> getAllProducts() {
        List<Product> productList = productRepo.findAll();
        if (productList.isEmpty()) {
            throw new ProductNotFoundException("No product records found");
        }
        return productList;
    }

    //to add a new product
    public void addProduct(Product product) {
        if (product.getName() == null || product.getPrice() <= 0 || product.getDescription() == null) {
            throw new InvalidProductException("Product data is invalid or incomplete");
        }
        productRepo.save(product);

    }

    //to get a product via id
    public ProductResponse getProductById(Long id) {

        Product product = productRepo.findById(id).orElseThrow(() -> new ProductNotFoundException("product with id: " + id + " is not found"));
        Integer stockQuantity = productInterface.getStockQuantity(product.getId()).getBody();
        if (stockQuantity == null) {
            throw new IllegalArgumentException("Stock quantity response is null for product ID " + product.getId());
        }

        ProductResponse productResponse = new ProductResponse(
                product.getId(),
                product.getName(),
                product.getDescription(),
                product.getPrice(),
                stockQuantity
        );


        return productResponse;
    }
}
