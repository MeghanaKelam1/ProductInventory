package com.app.Product_Inventory_Registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductInventoryRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
